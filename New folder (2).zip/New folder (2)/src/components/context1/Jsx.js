import renderHOC from "../HOC/renderHOC";
class Jsx{
    @renderHOC
    method (){
        return(
            <div>
                <span>manoj</span><p>prajapati</p>
            </div>
        );
    }
};