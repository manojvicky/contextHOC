import React from "react";
import ThemedButton from "./ThemedButton";
const Toolbar3 = (props) =>{
    return <ThemedButton/>
}
export default Toolbar3;