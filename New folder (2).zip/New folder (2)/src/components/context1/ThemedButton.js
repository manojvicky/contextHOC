import React from "react";
import {staticThemeContext} from "../../../context";
import ContextHOC from "../HOC/ContextHOC";
import renderHOC from "../HOC/renderHOC";
import {boundMethod} from 'autobind-decorator';



@ContextHOC(staticThemeContext)
class ThemedButton extends React.Component{
    static contextType = staticThemeContext;
    state={
        toggle: false,
        value: ""
    }
    @boundMethod
    render(){
        console.log("props of HOC", this.props);
        return <div {...this.props}><span {...this.props}>je baat</span><p {...this.props}>beta</p></div> 
    }
}
export default ThemedButton;
// ThemedButton.contextType = ThemeContext;