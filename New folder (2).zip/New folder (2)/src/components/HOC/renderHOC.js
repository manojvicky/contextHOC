function deepClone(obj){
    if(obj===null || obj===undefined || !(obj instanceof Object)){
        return obj;
    }

    let temp = obj.constructor();
    for(let o in obj){
        temp[o] = deepClone(obj[o]);
    }
    return temp;
}
function renderHOC(target, key, descriptor) {

    console.log("target", target);
    console.log("name", key);
    console.log("des", descriptor);
    let output = descriptor.value();
    console.log("output", output);
    let newProps = deepClone(output);
    console.log("newProps", newProps);
    if(Array.isArray(newProps.props.children)){
        newProps.props.children.map(child=>{
            const className="wrappedComponent";
            child.props.className=className;
        })
    }

    return function () {
        return output;
    };
    // return descriptor.value;
}
export default renderHOC;